```python
import pandas as pd
import numpy as np
```


```python
data = pd.read_csv('data/president_heights.csv')
```


```python
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>order</th>
      <th>name</th>
      <th>height(cm)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>George Washington</td>
      <td>189</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>John Adams</td>
      <td>170</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Thomas Jefferson</td>
      <td>189</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>James Madison</td>
      <td>163</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>James Monroe</td>
      <td>183</td>
    </tr>
  </tbody>
</table>
</div>




```python
heights = np.array(data['height(cm)'])
print(heights)
```

    [189 170 189 163 183 171 185 168 173 183 173 173 175 178 183 193 178 173
     174 183 183 168 170 178 182 180 183 178 182 188 175 179 183 193 182 183
     177 185 188 188 182 185]
    


```python
mean_height = np.mean(heights)
std_deviation = np.std(heights)
min_height = np.min(heights)
max_height = np.max(heights)
percentile_25 = np.percentile(heights, 25)
median = np.median(heights)
percentile_75 = np.percentile(heights, 75)

print("Mean height =", mean_height)
print("Standard deviation =", std_deviation)
print("Minimum height =", min_height)
print("Maximum height =", max_height)
print("25th percentile =", percentile_25)
print("Median =", median)
print("75th percentile =", percentile_75)
```

    Mean height = 179.73809523809524
    Standard deviation = 6.931843442745892
    Minimum height = 163
    Maximum height = 193
    25th percentile = 174.25
    Median = 182.0
    75th percentile = 183.0
    


```python
max_idx = np.argmax(heights)
min_idx = np.argmin(heights)

print("max_idx =", max_idx)
print("min_idx =", min_idx)
```

    max_idx = 15
    min_idx = 3
    


```python
max_name = data.iloc[max_idx]['name']
min_name = data.iloc[min_idx]['name']

print("The tallest president is", max_name)
print("The smallest president is", min_name)
```

    The tallest president is Abraham Lincoln
    The smallest president is James Madison
    


```python
from matplotlib import pyplot as plt
import seaborn
```


```python
%matplotlib inline
%config InlineBackend.figure_format = 'svg'
seaborn.set()

plt.hist(heights)
plt.title('Height Distribution of US President')
plt.xlabel('height (cm)')
plt.ylabel('number')
plt.show()
```


    
![svg](output_8_0.svg)
    



```python

```
